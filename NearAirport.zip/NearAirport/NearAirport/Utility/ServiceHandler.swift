//
//  ServiceHandler.swift
//  NearAirport
//
//  Created by Nandana on 30/07/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


enum NetworkError: Error {
    case failure
    case success
}

class ServiceHandler: NSObject {

    var searchResults = [JSON]()
    
    func fetchResult(completionHandler: @escaping ([JSON]?, NetworkError) -> ()) {
        
        let urlToSearch = "https://gist.githubusercontent.com/tdreyno/4278655/raw/7b0762c09b519f40397e4c3e100b097d861f5588/airports.json"
        Alamofire.request(urlToSearch).responseJSON { response in
            guard let data = response.data else {
                completionHandler(nil, .failure)
                return
            }
            
            let json = try? JSON(data: data)
            let results = json?.arrayValue
            guard let empty = results?.isEmpty, !empty else {
                completionHandler(nil, .failure)
                return }
            
            print("Show the results  \(String(describing: results))")
            completionHandler(results, .success)
        }
    }
    
    
}
