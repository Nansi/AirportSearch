//
//  AirportData.swift
//  NearAirport
//
//  Created by Nandana on 30/07/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import Foundation
import ObjectMapper

class AirportData: NSObject, Mappable
{
    
    var code: String?
    var latitude: String?
    var longitude: String?
    var name: String?
    var city: String?
    var state: String?
    var runwayLength: String?
    var country: String?
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        code          <- map[AirportConstants.airportCode]
        latitude      <- map[AirportConstants.airportLatitude]
        longitude     <- map[AirportConstants.airportLongitude]
        name          <- map[AirportConstants.airportName]
        city          <- map[AirportConstants.city]
        state         <- map[AirportConstants.state]
        runwayLength  <- map[AirportConstants.runwayLength]
        country       <- map[AirportConstants.country]
        
    }
}

