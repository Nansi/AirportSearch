//
//  AirportConstants.swift
//  NearAirport
//
//  Created by Nandana on 30/07/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit

class AirportConstants: NSObject {
    
    static let airportCode = "code"
    static let airportLatitude = "lat"
    static let airportLongitude = "log"
    static let airportName = "name"
    static let city = "city"
    static let state = "state"
    static let country = "country"
    static let runwayLength = "runway_length"

}
