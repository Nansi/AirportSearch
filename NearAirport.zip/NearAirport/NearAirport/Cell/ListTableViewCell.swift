//
//  ListTableViewCell.swift
//  NearAirport
//
//  Created by Behera, Nandana (Cognizant) on 30/07/2019.
//  Copyright © 2019 Behera, Nandana (Cognizant). All rights reserved.
//

import UIKit


class ListTableViewCell: UITableViewCell {

    @IBOutlet weak var portName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    

}
