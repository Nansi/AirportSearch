//
//  HomeViewController.swift
//  NearAirport
//
//  Created by Behera, Nandana (Cognizant) on 30/07/2019.
//  Copyright © 2019 Behera, Nandana (Cognizant). All rights reserved.
//

import UIKit
import SwiftyJSON

class HomeViewController: UIViewController {

    var AirportList = [AirportData]()
    private let apiFetcher = ServiceHandler()
    @IBOutlet weak var tableView: UITableView!
    var airportNames = [String]()
    var searchData = [String]()
    var selectedAirport : AirportData!
    
    private let searchController = UISearchController(searchResultsController: nil)
    private var previousRun = Date()
    private let minInterval = 0.05
    var searchActive = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchResults()
        
        setupSearchBar()
        
        
    }
    
    private func setupSearchBar() {
        searchController.searchBar.delegate = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.placeholder = "Search Airport"
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        tableView.tableFooterView = UIView()
    }
    
    func fetchResults() {
        
        
      
        if Reachability.isConnectedToNetwork() == true
        {
            //Fetch data from URL
            print(" Network Access is there")
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            MakeActivityIndicator.sharedInstance.showActivityIndicator(uiView:self.view)
            apiFetcher.fetchResult(completionHandler: {
                [weak self] results, error in
                if case .failure = error {
                    return
                }
                
                guard let results = results, !results.isEmpty else {
                    return
                }
                
                for status in results {
                    let paramsJSON = JSON(status)
                    let paramsString = paramsJSON.rawString(String.Encoding.utf8, options: JSONSerialization.WritingOptions.prettyPrinted)!
                    
                    let airportData = AirportData(JSONString: paramsString)
                    let city = airportData?.city
                    
                    self?.airportNames.append(city!)
                    self?.AirportList.append(airportData!)
                }
                self?.tableView.reloadData()
                
            })
            
            print("Show the Arrya\(AirportList)")
        }
        else
        {
            //No Netwrok , Fetch data from local DB
            print("No Network Access")
            
        }
        
    }


}

extension HomeViewController: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if searchActive
        {
            return searchData.count
        }
        else
        {
            return airportNames.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell",for: indexPath) as! ListTableViewCell
        
        if searchActive
        {
            cell.portName.text = searchData[indexPath.row]
        }
        else
        {
            cell.portName.text = airportNames[indexPath.row]
            
        }
        
        
        DispatchQueue.main.async {
            MakeActivityIndicator.sharedInstance.hideActivityIndicator(uiView: self.view)
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    
        
        tableView.deselectRow(at: indexPath, animated: true)
        let details = storyboard?.instantiateViewController(withIdentifier: "NearestAirportList") as! NearestAirportListViewController
        details.SelectedAirportList = AirportList
        details.selectedCity = searchData[indexPath.row]
        self.navigationController?.pushViewController(details, animated: true)
        
        
    }
}
extension HomeViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchData.removeAll()
        searchActive = true
        guard let textToSearch = searchBar.text, !textToSearch.isEmpty else {
            tableView.reloadData()
            return
        }
        
        if Date().timeIntervalSince(previousRun) > minInterval {
            previousRun = Date()
            fetchResults(for: textToSearch)
        }
    }
    
    func fetchResults(for text: String) {
        
        searchData = text.isEmpty ? airportNames : airportNames.filter({(dataString: String) -> Bool in
            // If dataItem matches the searchText, return true to include it
            return dataString.range(of: text, options: .caseInsensitive) != nil
        })
        print("show SearchData \(searchData)")
        tableView.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchData.removeAll()
        searchActive = false
        self.tableView.reloadData()
    }
}


